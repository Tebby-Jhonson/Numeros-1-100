 // Imprimir los números del 1 al 100
for (let i = 1; i <= 100; i++) {
    // Imprimimos el número en la consola
    console.log(i);
}