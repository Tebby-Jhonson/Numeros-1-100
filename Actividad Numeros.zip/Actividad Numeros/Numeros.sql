WITH Numeros AS (
  SELECT 1 AS Numero
  UNION ALL
  SELECT Numero + 1
  FROM Numeros
  WHERE Numero < 100
)
SELECT Numero
FROM Numeros;
